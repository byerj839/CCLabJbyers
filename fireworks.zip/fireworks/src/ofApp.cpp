#include "ofApp.h"
int col;

//--------------------------------------------------------------
void ofApp::setup(){
  ofBackground(0);
  //myParticle.setup(300, 300, ofColor(255, 0, 0));
    
}

//--------------------------------------------------------------
void ofApp::update(){
  //myParticle.update();
  
  for(int i=0; i < fireworks.size(); i++){
    fireworks[i].update();
  }

}

//--------------------------------------------------------------
void ofApp::draw(){
  //myParticle.draw();
    ofDrawBitmapString("Firework Color, PRESS: 'r' = red, 'g' = green, 'b' = blue", 10, 10);

  for(int i=0; i < fireworks.size(); i++){
    fireworks[i].draw();
  }
}
//--------------------------------------------------------------
void ofApp::keyPressed(int key){
 
    //Set a color based on key pressed
//    ofColor fireworkColor;
//    fireworkColor.setHsb(ofRandom(360), 192, 192);
    
    if(key == 'R' || key == 'r'){
        col = 0;
    }else if(key == 'G' || key == 'g'){
        col = 1;
    }else{
        col = 2;
    }
    
    
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
//  FireworkEmitter firework;
//  firework.setup(x, y);
//  fireworks.push_back(firework);
    
    FireworkEmitter firework;
    firework.setup(x, y, col);
    fireworks.push_back(firework);
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
