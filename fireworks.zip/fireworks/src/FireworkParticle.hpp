//
//  FireworkParticle.hpp
//  fireworks
//
//  Created by Julie Byers on 10/30/17.
//

#ifndef FireworkParticle_hpp
#define FireworkParticle_hpp

#include <stdio.h>
#include "ofMain.h"

class FireworkParticle{
  
public:
  void setup(int x, int y, ofColor color);
  void update();
  void draw();

private:
  ofPoint position, velocity, acceleration;
  int alpha, radius;
  ofColor color;

};

#endif /* FireworkParticle_hpp */
