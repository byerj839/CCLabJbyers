//
//  FireworkEmitter.cpp
//  fireworks
//
//  Created by Julie Byers on 10/30/17.
//

#include "FireworkEmitter.hpp"

void FireworkEmitter::setup(int x, int y, int col){
  position.set(x,y);
  
//  int numParticles = 350;
//  ofColor fireworkColor;
//  fireworkColor.setHsb(ofRandom(360), 192, 192);
    
    int numParticles = 350;
    ofColor fireworkColor;
    if(col == 0){
        fireworkColor.r = 255;
        fireworkColor.g = 0;
        fireworkColor.b = 0;
    }
    else if(col == 1){
        fireworkColor.r = 0;
        fireworkColor.g = 255;
        fireworkColor.b = 0;
    }
    else if(col == 2){
        fireworkColor.r = 0;
        fireworkColor.g = 0;
        fireworkColor.b = 255;
    }

  for(int i=0; i < 350; i++){
    FireworkParticle firework;
    firework.setup(position.x, position.y, fireworkColor);
    fireworkParticles.push_back(firework);
  }
  
}

void FireworkEmitter::update(){

  for(int i=0; i < fireworkParticles.size(); i++){
    fireworkParticles[i].update();
 
  }

}

void FireworkEmitter::draw(){

  for(int i=0; i < fireworkParticles.size(); i++){
        fireworkParticles[i].draw();
  }

}
