//
//  FireworkParticle.cpp
//  fireworks
//
//  Created by Julie Byers on 10/30/17.
//

#include "FireworkParticle.hpp"

void FireworkParticle::setup(int x, int y, ofColor color){

  position.set(x, y);
  this->color = color; //set obj color to argument that just came in, differeniate for compiler
  
  velocity.set(ofRandom(-1.2, 1.2), ofRandom(-1, 1));
  acceleration.set(0, ofRandom(0, 0.01));
  
  alpha = 255; //completely opaque to start
  radius = 2;
}

void FireworkParticle::update(){
  velocity += acceleration;
  position += velocity;

  alpha--;
}

void FireworkParticle::draw(){
  ofSetColor(color.r, color.g, color.b, alpha);
  ofDrawCircle(position, radius);
}

