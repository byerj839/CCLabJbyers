//
//  FireworkEmitter.hpp
//  fireworks
//
//  Created by Julie Byers on 10/30/17.
//

#ifndef FireworkEmitter_hpp
#define FireworkEmitter_hpp

#include <stdio.h>
#include "ofMain.h"
#include "FireworkParticle.hpp"

class FireworkEmitter{

public:
  void setup(int x, int y, int col);
  void update();
  void draw();
  
  ofPoint position;
  vector<FireworkParticle> fireworkParticles;
  int lifespan;

};

#endif /* FireworkEmitter_hpp */
