var room;
var couch1, couch2;
var room_side = 0;
var MARGIN = 0;
var step = 0;
var some = 1;
var scratcher = false;
var first_s = 0;
var use_rem = 0;
var act_rem = 0;
var use_yarn = 0;
var act_yarn = 0;
var use_cheese = 0;
var act_cheese = 0;
var use_mouse = 0;
var act_mouse = 0;
var inv = 0;
var drag = 0;

var scratch_photo_val = 0;
var critter_photo_val = 0;
var food_photo_val = 0;
var vet_photo_val = 0;
var plant_photo_val = 0;



function setup() {
  couch0 = loadImage("./assets/couch001.png");
  couch1 = loadImage("assets/couch002.png");
  couch2 = loadImage("assets/couch006.png");
  couch3 = loadImage("assets/couch004.png");
  
  mouse1 = loadImage("assets/mouse001.png");
  mouse2 = loadImage("assets/mouse002.png");
  mouse3 = loadImage("assets/mouse003.png");
  plant = loadImage("assets/plant001.png");
  remote = loadImage("assets/remote001.png");
  remote2 = loadImage("assets/remote002.png");
 
  door0 = loadImage("assets/door001.png");
  door01 = loadImage("assets/door002.png");
  door1 = loadImage("assets/door003.png");
  door11 = loadImage("assets/door004.png");
  door12 = loadImage("assets/yarndoor.png");
  condo = loadImage("assets/catscratch001.png");
  calendar = loadImage("assets/door006.png");
  yarn = loadImage("assets/yarn001.png");
  yarn2 = loadImage("assets/yarn002.png");
  
  table0 = loadImage("assets/table001.png");
  table1 = loadImage("assets/table002.png");
  table2 = loadImage("assets/table004.png");
  napkin = loadImage("assets/napkin001.png");
  bowls = loadImage("assets/table005.png");
  cheese = loadImage("assets/cheese001.png");
  cheese2 = loadImage("assets/cheese002.png");
  
  tv0 = loadImage("assets/tv001.png");
  tv1 = loadImage("assets/tv002.png");
  tv2 = loadImage("assets/tv003.png");
  tv11 = loadImage("assets/tv004.png");
  
  moveRight = loadImage("assets/moveright.png");
  moveLeft = loadImage("assets/moveleft.png");
  moveBack = loadImage("assets/moveback.png");
  closeThing = loadImage("assets/closeThing.png");
  inventory = loadImage("assets/Inventory.png");
  
  scratch_photo = loadImage("assets/war_scratch.png");
  critter_photo = loadImage("assets/critter.png");
  vet_photo = loadImage("assets/war_vet.png");
  food_photo = loadImage("assets/war_food.png");
  plant_photo = loadImage("assets/war_plants.png");
  
  escape_room = loadImage("assets/escaped.png");
  
  createCanvas(1280, 720);
  
}



function draw() {
   
  //Couch
  if(room_side === 0){
    if(step === 0){
      background(couch0); //Dark Couch
    }else if(step == 1){
      background(couch1); //Standard Couch
    }else if(step == 2){
      background(couch2); //table
      if(use_rem == 0) image(remote, 210, 315); //Show remote?
      image(plant, 313, 46);
    }else if(step == 3){
       background(couch3); //Under Couch
      if(use_cheese < 500) {image(mouse1, 154, 184);} //Mouse hidden
      else if(use_cheese == 500 && use_mouse == 0) {image(mouse2, 436, 413);} //Mouse Out
    }else{
      background(couch1);
    }
  }

  
  //Door
  if(room_side == 1){
    if(step === 0){
      if(scratcher == false) background(door0); //Dark, No Scratcher
      if(scratcher == true) background(door01); //Dark, Scratcher
    }else if(step == 1){
      if(scratcher == false) {background(door1);} //Light, No Scratcher
      else if(scratcher == true && use_yarn == 500) {background(door12);} //Yarn Connected
      else {background(door11); }
    }else if(step == 2){
      background(calendar); //Calendar
    }else if(step == 3){
       background(condo); //Condo Inside
      if(use_yarn == 0) image(yarn, 449, 301); //Show Yarn
    }else if(step == 5){  
      background(escape_room);
    }else{
      background(door11);
    }
  }
  
  
  
   //Table
  if(room_side == 2){
    if(step === 0){
      background(table0); //Dark 
    }else if(step == 1){
      background(table1); //Standard 
    }else if(step == 2){
      background(table2); //table
      if(use_cheese == 0) image(cheese, 197, 158); //Show cheese?
    }else if(step == 3){
       background(bowls); //Fod
    }else if(step == 4){
      background(table2); //Zoom in on napkin
      image(napkin, 167, 62);
    }else{
      background(table1);
    }
  }
  
  
  
  
  //TV
  if(room_side == 3){
    if(step === 0){
      background(tv0);
    }else if(step == 1){
      if(use_rem == 500) {background(tv11);}
      else{background(tv1);}
    }else if(step == 2){
      background(tv2);
    }else{
      background(tv1);
    }
  
  }
  
  
  
  //Lessons
   if(scratch_photo_val == 1) background(scratch_photo);
   if(critter_photo_val == 1) background(critter_photo);
   if(vet_photo_val == 1) background(vet_photo);
   if(food_photo_val == 1) background(food_photo);
   if(plant_photo_val == 1) background(plant_photo);
   
  
  //Drawing Inventory
  if(inv > 0){
    image(inventory, 0, height-75);
    
    if(act_rem == 0 && use_rem > 0){
      image(remote, 50, height-75, 75, 75);
    } else if(use_rem > 0 && use_rem != 500 && act_rem > 0){
      image(remote2, 50, height-75, 75, 75);
    } else if (use_rem == 500){
      image(remote, 50, height-75, 1, 1);
    }
      
    if(act_yarn == 0 && use_yarn > 0){
     image(yarn, 150, height-75, 75, 75);
    } else if(use_yarn > 0 && use_yarn != 500 && act_yarn > 0){
       image(yarn2, 150, height-75, 75, 75);
    } else if (use_yarn == 500){
       image(yarn, 150, height-75, 1, 1);
    }
      
      
    if(act_cheese == 0 && use_cheese > 0){
     image(cheese, 250, height-75, 75, 75);
    } else if(use_cheese > 0 && use_cheese != 500 && act_cheese > 0){
       image(cheese2, 250, height-75, 75, 75);
    } else if (use_cheese == 500){
       image(cheese, 250, height-75, 1, 1);
    }
    
    if(act_mouse == 0 && use_mouse > 0 && use_cheese==500){
     image(mouse2, 350, height-75, 75, 75);
    } else if(use_mouse > 0 && use_mouse != 500 && act_mouse > 0){
       image(mouse3, 350, height-75, 75, 75);
    } else if (use_mouse == 500){
       image(mouse2, 350, height-75, 1, 1);
    }
      
      
    //if(use_yarn > 0) image(yarn, 150, height - 75, 75, 75)
    //if(use_cheese > 0) image(cheese, 250, height-75, 75, 75);
  }
  
  
  if(step != 2 && step != 3 && step != 4){
    image(moveRight, width-50, height/2, 50, 50);
    image(moveLeft, 0, height/2, 50, 50);
  }else if(step == 2 || step == 3){
    image(moveBack, width/2, height-50, 50, 50);
  }else if(step == 4){
    image(closeThing, width/2, height-50, 50, 50);
  }else if(step == 5){
    text("you escaped the room!!");
  }
  
  
   if(step == 0){
    noStroke();
    fill(0);
    rect(0,0, width, 30);
    fill(255);
    textSize(14);
    text("Boy, it is dark! We need light to figure out a way to escape.", 0, 20);
  }

  
  
}

//Need function to make room not dark when window is clicked


function mousePressed() {
  
  
  //While not in the zoomed in state
  //Changes side of room you are viewing. 
  if(step != 2 && step != 3 && step != 4){
    if(mouseY <= height/2 + 50 && mouseY > height/2){
      if(mouseX > 0 && mouseX <=50){
        if(room_side == 0){
          room_side = 3;
        }else{
          room_side -= 1;
        }
      } 
      if(mouseX > width-50 && mouseX < width){
        if(room_side == 3){
          room_side = 0;

        }else{
          room_side += 1;
        }
      }
    }
  }else if(step == 2 || step == 3){ //Zoom in state
    if(mouseX > width/2 && mouseX < width/2 + 50 && mouseY > height-50 && mouseY < height){
       step = 1;

    }
  }else if (step == 4){
    if(mouseX > width/2 && mouseX < width/2 + 50 && mouseY > height-50 && mouseY < height){
       step = 2;

  }
    
  }


  
  //Couch, give a cat scratcher or zoom into under couch
  if(room_side == 0 && mouseX >= 234 && mouseX < 1025 && mouseY > 283 && mouseY < 583) {
    first_s += 1;
    if(first_s == 1) {
      room_side = 1;
      scratch_photo_val = 1;
    }else if (step == 1){
      step = 3;
    }
    scratcher = true; 
  }
  
  //Collect Mouse
    if(room_side == 0 && step == 3 && use_cheese == 500 && mouseX >= 436 && mouseX < 581 && mouseY > 415 && mouseY < 570) {
      use_mouse++;
      inv++;
    }
  
  //Coffee Table
  if(room_side == 0 && step == 1 && mouseX >= 1047 && mouseX < 1204 && mouseY > 256 && mouseY < 455) {
      step = 2;
  }
  
  //Collect Remote
  if(room_side == 0 && step == 2 && mouseX >= 210 && mouseX < 596 && mouseY > 315 && mouseY < 701){
    use_rem++;
    inv++;
  }
  
  //Plant Lesson
  if(room_side == 0 && step == 2 && mouseX >= 503 && mouseX < 826 && mouseY > 214 && mouseY < 487){
     if(plant_photo_val === 0) plant_photo_val ++;
  }
  
  //Cat Scratcher Zoom In
  if(room_side == 1 && step == 1 && mouseX >= 890 && mouseX < 1195 && mouseY > 108 && mouseY < 519) {
      step = 3;
  }
  
  //Collect Yarn
  if(room_side == 1 && step == 3 && mouseX >= 449 && mouseX < 768 && mouseY > 301 && mouseY < 620) {
      use_yarn++;
      inv++;
  }
  
  //Calendar Zoom In
  if(room_side == 1 && step == 1 &&  mouseX >= 247 && mouseX < 401 && mouseY > 46 && mouseY < 249) {
      step = 2;
      if(vet_photo_val === 0) vet_photo_val ++;
      
  }
  
   //Table Zoom
  if(room_side == 2 && step == 1 && mouseX >= 502 && mouseX < 1116 && mouseY > 226 && mouseY < 544) {
      step = 2;
  }
  
   //Collect Cheese
  if(room_side == 2 && step == 2 && mouseX >= 197 && mouseX < 329 && mouseY > 158 && mouseY < 290) {
      use_cheese++;
      inv++;
  }
  
   //Napkin on Table Open Up
  if(room_side == 2 && step == 2 && mouseX >= 330 && mouseX < 725 && mouseY > 365 && mouseY < 651) {
      step = 4;
  }

    //Cat Food
  if(room_side == 2 && step == 1 && mouseX >= 55 && mouseX < 259 && mouseY > 472 && mouseY < 529) {
      step = 3;
      
      if(food_photo_val === 0) food_photo_val ++;
  }
  
  
  //Make it not dark when window is clicked. 
  if(room_side == 3 && mouseX >= 140 && mouseX < 375 && mouseY > 0 && mouseY < 340) {
    if(step == 0){
      step = 1; //If it is dark change to light.
    }  
    else if(step == 1){
      step = 2; //Zoom in on window
    } 
  }
  
  //Activate
  
  if(inv > 0){
  
    if(mouseX >= 50 && mouseX < 125 && mouseY > height-75 && mouseY < height){
      if(act_rem == 0){
        act_rem = 1;
      }else if(act_rem == 1){
        act_rem = 0;
      }
    }
    else if(mouseX >= 150 && mouseX < 225 && mouseY > height-75 && mouseY < height){
      if(act_yarn == 0){
        act_yarn = 1;
      }else if(act_yarn == 1){
        act_yarn = 0;
      }
    }
    else if(mouseX >= 250 && mouseX < 325 && mouseY > height-75 && mouseY < height){
      if(act_cheese == 0){
        act_cheese = 1;
      }else if(act_cheese == 1){
        act_cheese = 0;
      }
    }
    else if(mouseX >= 350 && mouseX < 425 && mouseY > height-75 && mouseY < height){
      if(act_mouse == 0){
        act_mouse = 1;
      }else if(act_mouse == 1){
        act_mouse  = 0;

      }
    }
  }
  
  //Use
  //Remote
  if(act_rem == 1 && step == 1 && room_side == 3 && mouseX >= 515 && mouseX < 843 && mouseY > 180 && mouseY < 373){
    //step = 5;
    use_rem = 500;
  }
  //Yarn
  if(act_yarn == 1 && step == 1 && room_side == 1 && mouseX >= 518 && mouseX < 761 && mouseY > 13 && mouseY < 480){
    //step = 6; 
    use_yarn = 500;
  }
  //Cheese
  if(act_cheese == 1 && step == 3 && room_side == 0 && mouseX >= 112 && mouseX < 353 && mouseY > 115 && mouseY < 417){
    use_cheese = 500;
    critter_photo_val = 1;
  
  }
  //Mouse...ENDS GAME!!!
  if(act_mouse == 1 && step == 1 && use_yarn == 500 && room_side == 1 && mouseX >= 518 && mouseX < 761 && mouseY > 13 && mouseY < 480){
    use_mouse = 500;
    step = 5;
  
  }
  
  
  //Clicking to Remove Lessons
   if(scratch_photo_val == 1 && mouseX >= 474 && mouseX < 807 && mouseY > 489 && mouseY < 557){
    room_side = 1;
    scratch_photo_val = 2;
  }
  if(critter_photo_val == 1 && mouseX >= 474 && mouseX < 807 && mouseY > 489 && mouseY < 557){
    critter_photo_val = 2;
  }
  
  if(vet_photo_val == 1 && mouseX >= 474 && mouseX < 807 && mouseY > 489 && mouseY < 557){
    vet_photo_val = 2;
  }
  
  if(food_photo_val == 1 && mouseX >= 474 && mouseX < 807 && mouseY > 489 && mouseY < 557){
    food_photo_val = 2;
  }
  
  if(plant_photo_val == 1 && mouseX >= 474 && mouseX < 807 && mouseY > 489 && mouseY < 557){
    plant_photo_val = 2;
  }
  
  
}




