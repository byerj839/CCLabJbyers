//
//  Particle.hpp
//  particlesAdv
//
//  Created by Julie Byers on 11/6/17.
//


#ifndef Particle_hpp
#define Particle_hpp

#include <stdio.h>
#include "ofMain.h"

class Particle {
public:
  void reset();
  void update();
  void draw();
    
    void bounceOffWalls();
    void throughOffWalls();
    void resetToRandomPos();

  void toggleMode();
  
  ofPoint position;
  ofPoint velocity;
    ofPoint acceleration;
    float friction;
  ofPoint force;
    float radius;
    bool bFixed;
    float mass;
    float depth;
    float minx, miny, minz;
    float maxx, maxy, maxz;

  float drag;

  bool isAttracting = true;

};

#endif /* Particle_hpp */
