//
//  Particle.cpp
//  particlesAdv
//
//  Created by Julie Byers on 11/6/17.
//
//This is a simplified version of the particle example that comes default with OF


#include "Particle.hpp"


void Particle::reset(){
  
    
  //Give you a random position within the width/height of your window
  position.x = ofRandomWidth();
  position.y = ofRandomHeight();
  
  velocity.x = ofRandom(-3.9, 3.9);
  velocity.y = ofRandom(-3.9, 3.9);

  drag = ofRandom(0.95, 0.998);
  
  force = ofPoint(0,0,0);
     acceleration.set(0, 0, 0);
    
    radius = 5.0;
    friction = 0.01;
    mass = 1.0;
    minx = 0;
    miny = 0;
    minz = -ofGetHeight();
    maxx = ofGetWidth();
    maxy = ofGetHeight();
    maxz = ofGetHeight();
 

}

void Particle::update(){

  if(isAttracting){
    //Attraction code

    ofPoint attractPoint = ofPoint(ofGetMouseX(), ofGetMouseY());
    ofPoint attractPoint2 = ofPoint(ofGetMouseX() * 2, ofGetMouseY() / 2);
    
    //trying to figure out what direction the force is going in
    force = attractPoint - position;

    //Force applied mostly to those particles around attraction point. 
    force.normalize();

    
    velocity *= drag;
    //0.6 = arbitrary dampen of the force
    velocity += force * 0.6;
      
      acceleration -= velocity * friction;
      velocity += acceleration;
      position += velocity;
      acceleration.set(0,0,0);

    
  
  }else{

    //Repulsion

      ofPoint repulsePoint = ofPoint(ofGetMouseX(), ofGetMouseY());
      //Two repulse points
      ofPoint repulsePoint2 = ofPoint(ofGetMouseX() * 2, ofGetMouseY() / 2);
      force = repulsePoint - position;
     
    
      float distance = force.length();
      force.normalize();

      if(distance < 150) velocity -= force * 0.6;

  }

  position += velocity; 
}

void Particle::draw(){

  if(isAttracting){
    ofSetColor(255, 63, 180);
  }else{
    ofSetColor(208, 255, 63);
  }
   
  ofDrawCircle(position.x, position.y, radius);


}

void Particle::bounceOffWalls(){
    if (position.x > maxx){
        position.x = maxx;
        velocity.x *= -1;
    }
    if (position.x < minx){
        position.x = minx;
        velocity.x *= -1;
    }
    if (position.y > maxy){
        position.y = maxy;
        velocity.y *= -1;
    }
    if (position.y < miny){
        position.y = miny;
        velocity.y *= -1;
    }
    if (position.z > maxz){
        position.z = maxz;
        velocity.z *= -1;
    }
    if (position.z < minz){
        position.z = minz;
        velocity.z *= -1;
    }
}

void Particle::throughOffWalls(){
    if (position.x < minx) {
        position.x = maxx;
    }
    if (position.y < miny) {
        position.y = maxy;
    }
    if (position.z < minz) {
        position.z = maxz;
    }
    if (position.x > maxx) {
        position.x = minx;
    }
    if (position.y > maxy) {
        position.y = miny;
    }
    if (position.z > maxz) {
        position.z = minz;
    }
}

void Particle::resetToRandomPos(){
    float minx = 0;
    float miny = 0;
    float maxx = ofGetWidth();
    float maxy = ofGetHeight();
    float maxz = depth;
    float minz = -depth;
    if (position.x < minx || position.y < miny || position.z < minz || position.x > maxx || position.y > maxy || position.z > maxz) {
        position.set(ofRandom(minx, maxx), ofRandom(miny, maxy), ofRandom(minz, maxz));
    }
}


void Particle::toggleMode(){

  isAttracting = !isAttracting;
  reset();

}
